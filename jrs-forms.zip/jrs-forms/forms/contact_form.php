<?php
###############################################################
## IMPORTANT NOTE !!!!!
## If form fields are added, removed or the names are changed AFTER 
## data collection has started for this form, you MUST change the 
## form id or the admin report results will be messed up.
###############################################################
?>
<form name='contact' id='contact' class='standard_form' method='post' action=''>

	<div class='field_wrapper first_name'>
		<label>First Name*</label>
		<input required type='text' name='first_name' id='first_name' value=''>
	</div>
	<div class='field_wrapper last_name'>
		<label>Last Name*</label>
		<input required type='text' name='last_name' id='last_name' value=''>
	</div>
	<div class='field_wrapper email'>
		<label>Email*</label>
		<input required type='email' name='email' id='email' value=''>
	</div>
	<div class='field_wrapper phone'>
		<label>Phone*</label>
		<input required  type='tel' name='phone' id='phone' value=''>
	</div>
	<div class='field_wrapper company'>
		<label>Company*</label>
		<input required type='text' name='company' id='company' value=''>
	</div>
	<?php
	### company_size IS A HONEYPOT FIELD
	### It's disguised to make a robot think it's a required form field.
	### If a bot fills in this field before submitting the form
	### 	it will be rejected.
	?>
	<div class='field_wrapper company_size'>
		<label>Company Size*</label>
		<input required type='text' name='company_size' id='company_size' value=''>
	</div>
	<div class='field_wrapper location'>
		<label>City/State*</label>
		<input required type='text' name='location' id='location' value=''>
	</div>
	
	<div class='field_wrapper contact_reason'>
		<?php
		### Basic example of a select with an "Other" option
		### If "Other" is selected, an input appears to hold the value of "Other"
		?>
		<label>Contact Reason</label>
		<select name='contact_reason' id='contact_reason'>
			<option value="">Reason for contact</option>
			<option value="Manufacturer Requesting Sales Representation">Manufacturer Requesting Sales Representation</option>
			<option value="Pricing Quote Request">Pricing Quote Request</option>
			<option value="Need Assistance from a PSI Sales Rep">Need Assistance from a PSI Sales Rep</option>
			<option value="Combustion Analyzer Calibration">Combustion Analyzer Calibration</option>
			<option value="Literature Request">Literature Request</option>
			<option value="Other">Other</option>
		</select>
		<div class='contact_reason_other other'>
			<label>Reason</label>
			<input type='text' name='contact_reason_other' id='contact_reason_other' value=''>
		</div>			
	</div>
	
	<div class='field_wrapper'>
		<label>Comments</label>
		<textarea name='comments' id='comments'></textarea>
	</div>	

	<div class='field_wrapper'>
		<button class='btn button'>Submit</button>
	</div>

	<div class='msg'></div>
	
</form>
<p>* Required</p>
