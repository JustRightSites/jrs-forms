
jQuery(document).ready(function($) {

	// Auto run report when the start date is changed
	if ($("#jrs-forms_submission_date_start").val() !== "") {
		jrs_forms_run_report($);
	}

	// Auto run report when the form name is changed
	$(".jrs-forms_filter_form input, .jrs-forms_filter_form select").change(function() {
		jrs_forms_run_report($);
	});
	
	// Run the report when the form button is clicked
	$(".jrs-forms_run_report").click(function() {
		jrs_forms_run_report($);
	});
	
	// Print the report
	$(document.body).on("click", "#jrs-forms_admin #jrs-forms_controls .print", function() {
		export_data($, 'print');
	});
	
	// Export the report to .csv
	$(document.body).on("click", "#jrs-forms_admin #jrs-forms_controls .export", function() {
		export_data($, 'export');
	});

});

// Calls AJAX to pull and display report data
function jrs_forms_run_report($) {
	
	$("#jrs-forms_message, #jrs-forms_report_results").html(""); 
	
	var sub_start = $("#jrs-forms_submission_date_start").val();
	var sub_end = $("#jrs-forms_submission_date_end").val();
	var form_name = $("#jrs-forms_submiss").val();
	
	if (sub_start === "") {
		alert("Please provide at start date.");
		return;
	}
	
	$.ajax({
		url: ajaxurl,
		type: 'post',
		data: {'action' : 'jrs_forms_run_report', 'sub_start' : sub_start, 'sub_end' : sub_end, 'form_name' : form_name },
		datatype: 'json',
	}).done(function(response) {
		resp = JSON.parse(response);
		if (resp.stat === 'no') {
			var msg = "<div class='alert alert-danger'>" + resp.msg + "</div>";
		}else if (resp.data !== "") {
			$("#jrs-forms_report_results").html(resp.data);
			var msg = "<div class='alert alert-success'>" + resp.msg + "</div>";
		}
		$("#jrs-forms_message").html(msg);
	});

}

// Export report content to printer (pdf) or .csv file
function export_data($, act) {

	var sub_start = pretty_date($("#jrs-forms_submission_date_start").val());
	var sub_end = pretty_date($("#jrs-forms_submission_date_end").val());
	var form_name = "";
	if ($( "#jrs-forms_submiss" ).val() !== "") {
		form_name = $( "#jrs-forms_submiss option:selected" ).text();
	}
	
	var title;
	if (sub_end === "") {
		title = "<h1>After " + sub_start;
	}else{
		title = "<h1>Between " + sub_start + " - " + sub_end;
	}
	if (form_name !== "") { title += "<br>Form Name: " + form_name; }
	title += "</h1>\n";

	// ## Hacky trick to add a spinner to the button for a few seconds.
	$("#jrs-forms_controls button." + act).html("<img style='height: 1.5em; width: 1.5em;' src='../wp-content/plugins/jrs-forms/assets/imgs/spinner.svg' alt='Export'>");
	setTimeout(function() {
		btn_text = act.substr(0, 1).toUpperCase() + act.substr(1, act.length - 1);
		$("#jrs-forms_controls button." + act).html(btn_text);
	}, 4000);
	
	switch (act) {
		case 'print': print_report($); break;
		case 'export': export_report($);  break;
	}
	
}

// Export as a tab delimited .txt file
function export_report($) {

	var body = hdr = "";
	var url = window.location.href;
	url = url.substr(0, url.search("/wp-admin"));
	
	$("#jrs-forms_report_results tr").each(function() {
		if ($(this).find("th").length) {
			$(this).find("th").each(function() {
				hdr += $(this).html() + "\t";
			});
		}else if ($(this).find("td").length) {
			if (hdr !== "") {
				if (body !== "") {
					body = body + "\r\n\r\n" + hdr + "\r\n";
				}else{
					body = hdr + "\r\n";
				}
				hdr = "";
			}

			$(this).find("td").each(function() {
				body += $(this).html()+ "\t";
			});
			body += "\r\n";
		}
	});
	
	const link = document.createElement("a");
	const file = new Blob([body], { type: 'text/plain' });
	link.href = URL.createObjectURL(file);
	link.download = "jrs-forms-export.txt";
	link.click();
	URL.revokeObjectURL(link.href);
	
}

// Print report	
function print_report($) {
	var body = $("#jrs-forms_report_results").html();
	var url = window.location.href;
	var title = $(".jrs-forms_inner_wrapper h1").html();
	var start_date = $("#jrs-forms_submission_date_start").val();
	var end_date = $("#jrs-forms_submission_date_end").val();
	var daterange;
	if (end_date === "") {
		daterange = "Submitted from " + pretty_date(start_date);
	}else{
		daterange = "Submitted between " + start_date + " to " + end_date;
	}
	
	url = url.substr(0, url.search("/wp-admin"));
	var now = get_todays_date();

	title = "<h1>" + title + "</h1>\n";
	title += "<div>" + daterange + "</div>\n";
	title += "<div class='small_font'>Print date:" + now + "</div>\n";
	
	body = "<div id='jrs-forms_admin'>\n" + title + body + "</div>\n";
	
	var pg_hdr = "<html><head>";
	pg_hdr += "<title>Form Submissions Report</title>\n";

	pg_hdr += "<link rel='stylesheet' id='jrs-forms_admin-css' href='" + url + "/wp-content/plugins/jrs-forms/assets/css/jrs-forms_print.css' ver='1.0' media='all' />\n";
	pg_hdr += "</head>\n<body>\n";
	
	var pg_ftr = "</body>\n</html>\n";

	var newWin = window.open('','Print-Window');
	newWin.document.open();
	newWin.document.write(pg_hdr + body + pg_ftr);
	setTimeout(function() {
		newWin.print();
		newWin.onafterprint = newWin.close();
	}, 500);
}

function pretty_date(dat) {
	
	if (dat === "") return dat;
	
	//xxxx-xx-xx
	var ret_dat = dat;
	var m = dat.substr(5, 2);
	var d = dat.substr(8, 2);
	var y = dat.substr(0, 4);
	
	ret_dat = m + "/" + d + "/" + y;
	
	return(ret_dat);
	
}

function get_todays_date() {
	
	const today = new Date();

	const day = today.getDate(); // Get day of the month (1-31)
	const month = today.getMonth() + 1; // Get month (0-11, add 1 for 1-12)
	const year = today.getFullYear(); // Get full year (4 digits)

	// Format the date as desired (e.g., "mm/dd/yyyy")
	const formattedDate = `${month}/${day}/${year}`;

	return formattedDate;
}