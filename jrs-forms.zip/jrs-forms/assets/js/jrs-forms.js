jQuery(document).ready(function($) {

	/* ################# CUSTOM ################# */
	/* 		Toggle the "Other" fields as needed   */
	$(document.body).on("change", "#request_services #request_product", function() {
		if ($(this).val() === 'Other') {
			$("#request_product_other").prop("required", true);
			$("div.request_product_other").slideDown();
		}else{
			$("#request_product_other").prop("required", false);
			$("div.request_product_other").val("").slideUp();
		}
	});
	
	$(document.body).on("change", "#contact #contact_reason", function() {
		if ($(this).val() === 'Other') {
			$("#contact_reason_other").prop("required", true);
			$("div.contact_reason_other").slideDown();
		}else{
			$("#contact_reason_other").prop("required", false);
			$("div.contact_reason_other").val("").slideUp();
		}
	});	
	/* ################# CUSTOM ################# */

	// User clicked to submit form
	$(document.body).on("click", "form.standard_form button", function(e) {
		e.preventDefault();
		var form_id = $(this).parent().parent().attr("id");
		process_form($, form_id);		
	});
	
});

function process_form($, form_id) {

	var form_id_ele = "#" + form_id;
	var err = [];
	var fld = [];
	var fldval = [];
	var msg = first_fld = '';
	$(form_id_ele + " .msg").html("");

	// This is where the honeypot is tested if there is one
	// The default is company_size but change this as needed.
	/* ################# CUSTOM ################# */
	if ($("input#company_size").val() !== "") { 
		err.push("Your message could not be sent.");
	}else{
		// Loop the inputs and selects and collect the data
		// Add code as needed for other field types
		$(form_id_ele + " input, " + form_id_ele + " select").each(function() {
			id = $(this).attr("id");
			valu = $(this).val();
			if (id !== 'company_size') {
				// Test that required fields have values
				if ($(this).attr("required") === 'required' && ((valu === '') || ($(this).prop("type").toLowerCase() === 'checkbox' && !$(this).is(':checked')))) {
					if (first_fld === '') { first_fld = id; }
					err.push(id.toUpperCase() + " is a required field.");
					$("#" + id).addClass('alert-danger').attr("placeholder", "required");
				}else{	// Collect the field names and data
					fld.push(id);				
					if ($(this).prop("type").toLowerCase() === 'checkbox' || $(this).prop("type").toLowerCase() === 'radio') {
						if ($(this).is(':checked')) {
							fldval.push(valu);
						}else{
							fldval.push('');
						}						
					}else{
						fldval.push(valu);
					}
				}
			}
		});

		/* ################# CUSTOM ################# */
		// The code includes two sample forms
		// Customize here as needed if you rename or add new forms
		switch (form_id_ele) {
			case "#request_services":
				if ($("#request_product").val() === "Other" && $("#request_product_other").val() === "") {
					err.push("Please enter a product name.");
				}
				break;
			case "#contact":
				if ($("#contact_reason").val() === "Other" && $("#contact_reason_other").val() === "") {
					err.push("Please enter a contact reason.");
				}
				break;
		}
		/* ################# CUSTOM ################# */
		
	}
	
	// Stop if errors were found
	// Return messages
	if (err.length > 0) {
		for (i=0; i<err.length; i++) {
			msg += "<div class='alert alert-danger'>" + err[i] + "</div>\n";
		}

		$(form_id_ele + " .msg").html(msg);
		if (typeof(first_fld) !== 'undefined') {
			$("#" + first_fld).focus();
		}
		return;
	}
	
	// Call AJAX to store the request in the database as well as send an email to the specified recipient
	// The default is the site admin email
	var flds = JSON.stringify(fld);
	var vals = JSON.stringify(fldval);
	$.ajax({
		url: ajaxurl,
		type: 'post',
		data: {'action' : 'send_request', 'flds' : flds, 'vals' : vals, 'form_id' : form_id },
		datatype: 'json',
	}).done(function(response) {
		resp = JSON.parse(response);

		if (resp.stat === 'no') {
			var msg = "<div class='alert alert-danger'>" + resp.data + "</div>";
		}else if (resp.data !== "") {
			var msg = "<div class='alert alert-success'>" + resp.data + "</div>";
			$(form_id_ele + " input, " + form_id_ele + " select").val("");
			$(form_id_ele + " input[type='radio'], " + form_id_ele + " input[type='checkbox']").prop("checked", false);
		}
		$(form_id_ele + " .msg").html(msg); 
	});
	
	
}